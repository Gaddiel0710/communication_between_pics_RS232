//codigo de decodificador
#include <16f877a.h> //libreria del microcontrolador
#DEVICE adc=10 //resolucion de trabajo
#use delay (clock = 4M) //tiempo del reloj
#fuses xt, nowdt 
#use rs232 (baud=9600, xmit=pin_C6, rcv=pin_C7, parity=N, bits=8) //
#use i2c(Master,Fast=100000, sda=PIN_C4, scl=PIN_C3,force_sw)  // librer�� para manejar la comunicaci�n I2C
#include "i2c_Flex_LCD.c" //driver para manejar la interface LCD I2C
#use standard_io(A)

char letra;
int i=1;

void main ()
{
   lcd_init(0x4E,16,2); //inicializacion de la lcd
   lcd_backlight_led(ON); //encendido de la luz de fondo
   lcd_putc("PIC Receiver"); //mensaje inicial del codigo
  while (TRUE)
  {
   letra=getc();
   lcd_gotoxy(i,2);
   printf(lcd_putc,"%c",letra);
   i++; 
   delay_ms(500);  
      
   }
 }    
    
  
